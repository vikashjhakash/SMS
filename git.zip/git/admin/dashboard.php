<?php 
	require '../global/data.php'; // contains all the global names and data
	require 'head.php'; // contains the head part
	
	echo"<body>"; // body tab
	
	require 'navbar.php'; // contains the navbar
	require 'footerMenu.php'; // contains the footer navbar
?>
  
	<div class="container upper-part main_container">
	</div>
</body>
</html>
