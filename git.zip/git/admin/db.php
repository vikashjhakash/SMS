<?php

try{
$connect=mysqli_connect("localhost","root","") or die(mysql_error);
$database=mysqli_select_db($connect,"SMS");
	if($database){
		echo"connected";
	}
	else {
		throw new Exception('Operation cannot be performed now. Please contact the server administrator for further assistance. (Error: database)');
	}
}
catch(Exception $e){
	echo $e->getMessage();
}
?>