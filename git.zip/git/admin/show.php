<?php 
require 'db.php';
$main=$_POST['page'];
try{
	if ($main=='main-leaves'){
		
	}
}
catch(Exception $e){
	echo"error found";
}
?>