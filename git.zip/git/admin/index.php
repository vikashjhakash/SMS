<?php 
	require '../global/data.php'; // contains all the global names and data
	require 'head.php'; // contains the head part
	
	echo"<body class='login_background'>"; // body tab
	
	//require 'navbar.php'; // contains the navbar
?>
  
<div class="jumbotron container" style="background:transparent;">	
		<div class="container" >
			<div class="row" >
				<div class="col-md-3">
				</div>
				<div class="col-md-6 ">
				<div class="jumbotron" style="background:transparent"></div>
					<div class="panel panel-default" style="-webkit-box-shadow: 0px 0px 138px 30px rgba(0,0,0,0.38); -moz-box-shadow: 0px 0px 138px 30px rgba(0,0,0,0.38); box-shadow: 0px 0px 138px 30px rgba(0,0,0,0.38);">
						<div class="panel-heading">
							<span class="glyphicon glyphicon-lock"></span> Login With Valid Credentials</div>
						<div class="panel-body">
							<form class="form-horizontal" role="form" method="POST">
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-3 control-label">
									User ID</label>
								<div class="col-sm-9">
									<input type="text" class="form-control" id="username" name="username" placeholder="User ID" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputPassword3" class="col-sm-3 control-label">
									Password</label>
								<div class="col-sm-9">
									<input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
								</div>
							</div>
							<div class="form-group">
								<label for="role" class="col-sm-3 control-label">
									You Are</label>
								<div class="col-sm-9">
									<input type="radio" name="gender" value="parent"> Parent / Student &ensp;
									<input type="radio" name="gender" value="staff"> Teacher / Staff &ensp;
									<input type="radio" name="gender" value="admin"> Administrator
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-offset-3 col-sm-9">
									<div class="checkbox" id="rem" name="rem">
										<label>
											<input type="checkbox"/>
											Remember me
										</label>
									</div>
								</div>
							</div>
							<div class="form-group last">
								<div class="col-sm-offset-3 col-sm-9">
									<button type="submit" class="btn btn-success btn-sm" name="submit" id="submit">
										Sign in</button>
										 <button type="reset" class="btn btn-default btn-sm">
										Reset</button>
								</div>                        
							</div>
							<div class="form-group">
								<div class="col-sm-9">
								<?php 
								if(isset($_SESSION['error'])){
									if($_SESSION['error']!=""){
										echo "<span style='align:center;color:red;'><b>".$_SESSION['error']."</b></span>";
									}
								}
								?>
								</div>						
							</div>						
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>			
	</div>
	

</body>
</html>
