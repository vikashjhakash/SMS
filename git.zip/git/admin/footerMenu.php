
<nav class="navbar navbar-inverse navbar-fixed-bottom">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#footer">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" title="<?php echo "Developer - $developerName"; ?>" href='<?php echo "$DeveloperCompanyURL"; ?>'><small><?php echo "Developed by - $developer"; ?></small></a>
    </div>
    <div class="collapse navbar-collapse" id="footer">
     
      <ul class="nav navbar-nav navbar-right">
		<?php
			foreach($footerMenu as $showfooterMenu)
			{
				echo"<li><a href='$showfooterMenu'> $showfooterMenu</a></li>";
			}
		?>
      </ul>
    </div>
  </div>
</nav>