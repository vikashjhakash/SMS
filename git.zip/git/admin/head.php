<!DOCTYPE html>
<html lang="en">
<head>
  <title><?php echo "$SchoolName - $AdminDashboardName"; ?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../global/css/bootstrap.css">
  <link rel="stylesheet" href="../global/css/custom.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="../global/js/bootstrap.min.js"></script>
  <script src="../global/js/custom.js"></script>
</head>