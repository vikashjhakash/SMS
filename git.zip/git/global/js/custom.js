$(document).ready(function(){
	try{
		$.ajax({
			url: 'show.php',
			method: 'POST',
			data:{page:'main-leaves'},
			success: function(data){
				if(data){
					$('.main_container').append("<div id='leaves' class='col-sm-4'></div>");
					$('#leaves').html(data).css('color','red');
				}
				else throw(e)
			}
		});
	}

	catch(e){
		alert(e);
	}
})