
<?php
/* this page contains the variables with the global data. */
$SchoolName = "School"; // Shows the school name
$AdminDashboardName = "Admin Dashboard";
$menu = ['Home', 'Add Student', 'Remove Student', 'Add Staff', 'Remove Staff', 'Update Fee', 'Update Salary'];
$footerMenu = ['Notifications', 'Feedback', 'Create Meeting', 'Leaves', 'Online Exams', 'Complains', 'Attendance'];
$developer="We Develop Online";
$developerName="Vikash Mishra";
$DeveloperCompanyURL="http://wedeveloponline.com/";



?>